package com.example.trabalho_lab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
